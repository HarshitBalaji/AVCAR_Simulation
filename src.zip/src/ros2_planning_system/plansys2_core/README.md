# PlanSys2 Core

This package hosts the abstract interface (virtual base classes) for plugins to be used with the following:
- Planner (e.g., `popf`, `downward`)
