^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package plansys2_tools
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Forthcoming
-----------
* Merge remote-tracking branch 'origin/humble-devel'
* Merge remote-tracking branch 'origin/master' into fix_goal_structure_issue_205
* Merge remote-tracking branch 'upstream/master'
* Contributors: Francisco Martín Rico, Marco Roveri, Splinter1984

2.0.9 (2022-07-10)
------------------
* Humble Upgrade
* Contributors: Francisco Martín Rico

2.0.8 (2022-05-04)
------------------
* Add missing dependency
* Contributors: Francisco Martín Rico

2.0.7 (2022-05-04)
------------------

2.0.6 (2022-05-03)
------------------

2.0.5 (2022-05-03)
------------------
* Fix package dep
* Contributors: Francisco Martín Rico, Jake Keller, Marco Roveri

2.0.4 (2022-05-03)
------------------
* Fix version
* Fix ROS2 Buildfarm error due to Threads
* Adding missing build dependencies
* Merge branch 'IntelligentRoboticsLabs:master' into master
* Contributors: Francisco Martín Rico, Jake Keller, Marco Roveri

2.0.3 (2022-04-03)
------------------
* Qt5 dependencies
* Contributors: Francisco Martín Rico

2.0.2 (2022-04-03)
------------------
* Fixed compilation of main (working on galactic) to compile also on foxy
* RQT Plan viewer
* Logger tool - performers and plan
* Logger tool - knowledge, info and action hub
* Contributors: Francisco Martín Rico, Jake Keller, Marco Roveri

2.0.1 (2022-02-03)
------------------

2.0.0 (2021-07-04)
------------------

1.0.10 (2021-07-03)
-------------------

1.0.9 (2021-03-15)
------------------

1.0.8 (2021-03-12)
------------------

1.0.7 (2021-01-04)
------------------

1.0.6 (2020-12-29)
------------------

1.0.5 (2020-12-28)
------------------

1.0.4 (2020-12-24)
------------------

1.0.3 (2020-12-23 19:46)
------------------------

1.0.2 (2020-12-23 11:12)
------------------------

1.0.1 (2020-07-19)
------------------

0.0.7 (2020-03-26)
------------------

0.0.6 (2020-03-23)
------------------

0.0.5 (2020-01-12)
------------------

0.0.4 (2020-01-09 07:55)
------------------------

0.0.3 (2020-01-09 07:11)
------------------------

0.0.2 (2020-01-08)
------------------
