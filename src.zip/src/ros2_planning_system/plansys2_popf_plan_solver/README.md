# POPF Plan solver

This package contains a plan solver that uses [popf](https://github.com/fmrico/popf) for solving PDDL plans.
